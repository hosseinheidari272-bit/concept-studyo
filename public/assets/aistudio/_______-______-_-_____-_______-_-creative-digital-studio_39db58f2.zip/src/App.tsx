import React, { useState, useEffect } from 'react';
import { TopBar } from './components/TopBar';
import { HeroSection } from './components/HeroSection';
import { StudioHighlights } from './components/StudioHighlights';
import { ServicesSection } from './components/ServicesSection';
import { OrderModal } from './components/OrderModal';
import { AuthModal } from './components/AuthModal';
import { AdminPanel } from './components/AdminPanel';
import { UserChatModal } from './components/UserChatModal';
import { Footer } from './components/Footer';
import { ThreeHeroCanvas } from './components/ThreeHeroCanvas';
import { ServiceItem } from './types';
import { studioServices } from './data/services';
import { AuthProvider } from './context/AuthContext';

function AppContent() {
  const [services, setServices] = useState<ServiceItem[]>(studioServices);
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

  // حالت مدال چت و درخواست‌های کاربر
  const [isChatModalOpen, setIsChatModalOpen] = useState(false);
  const [chatInitialOrderId, setChatInitialOrderId] = useState<string | undefined>(undefined);
  const [chatInitialOrderTitle, setChatInitialOrderTitle] = useState<string | undefined>(undefined);

  // واکشی لیست خدمات از بک‌اند
  const fetchServices = async () => {
    try {
      const res = await fetch('/api/services');
      if (res.ok) {
        const data = await res.json();
        if (data.services && data.services.length > 0) {
          setServices(data.services);
        }
      }
    } catch {
      // استفاده از داده‌های پیش‌فرض در صورت آفلاین بودن
    }
  };

  useEffect(() => {
    fetchServices();
  }, []);

  const handleOpenOrder = (service: ServiceItem) => {
    setSelectedService(service);
    setIsOrderModalOpen(true);
  };

  const handleCloseOrderModal = () => {
    setIsOrderModalOpen(false);
    setSelectedService(null);
  };

  const handleOpenChat = (orderId?: string, orderTitle?: string) => {
    setChatInitialOrderId(orderId);
    setChatInitialOrderTitle(orderTitle);
    setIsChatModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#04070D] text-slate-100 relative overflow-x-hidden selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* ۱. پس‌زمینه سه‌بعدی سبک و روان (Three.js 3D Wave Canvas) */}
      <ThreeHeroCanvas />

      {/* ۲. نورهای محیطی ملایم و کنترل‌شده (Ambient Glows) */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-[radial-gradient(ellipse_at_center,rgba(0,180,255,0.09)_0%,rgba(0,0,0,0)_70%)] pointer-events-none z-0"
        aria-hidden="true"
      />
      <div
        className="absolute top-[850px] right-0 w-[550px] h-[450px] bg-[radial-gradient(ellipse_at_center,rgba(0,229,255,0.06)_0%,rgba(0,0,0,0)_70%)] pointer-events-none z-0"
        aria-hidden="true"
      />

      {/* ۳. محتوای لندینگ پیج با چیدمان استاندارد و ریتم مشخص */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 pt-5 pb-20">
        
        {/* نوار ناوبری ارتقایافته (Zone 1: Brand | Zone 2: Links | Zone 3: Actions) */}
        <TopBar
          onOpenChat={() => handleOpenChat()}
          onOpenOrderModal={() => handleOpenOrder(services[0] || studioServices[0])}
        />

        {/* بخش هیرو با هویت مستقل، تیتر قوی و اثبات آماری (Hero Section with Point of View) */}
        <main>
          <HeroSection
            onOpenOrderModal={() => handleOpenOrder(services[0] || studioServices[0])}
            onOpenChat={() => handleOpenChat()}
          />

          {/* شاخص‌های تمایز و استانداردهای کیفی (Four Pillars of Distinction) */}
          <StudioHighlights />

          {/* اکوسیستم خدمات تخصصی با فیلتر دسته‌بندی و کارت‌های اختصاصی */}
          <ServicesSection
            services={services}
            onSelectService={handleOpenOrder}
            onOpenChatForService={(srv) => handleOpenChat(undefined, srv.title)}
          />
        </main>

        {/* فوتر رسمی و معتبر استودیو */}
        <Footer onOpenChat={() => handleOpenChat()} />

      </div>

      {/* دکمه شناور چت و استعلام اختصاصی با ارگونومی مناسب برای موبایل و دسکتاپ */}
      <aside aria-label="دکمه شناور گفت‌وگو" className="fixed bottom-5 left-5 z-40">
        <button
          onClick={() => handleOpenChat()}
          title="گفت‌وگو و ارتباط مستقیم با مدیریت استودیو"
          className="group relative flex items-center gap-2.5 px-4 py-3 rounded-full bg-slate-900/95 hover:bg-slate-850 border border-cyan-500/50 hover:border-cyan-400 text-white shadow-[0_8px_30px_rgba(0,0,0,0.6)] hover:shadow-[0_8px_30px_rgba(0,229,255,0.35)] transition-all duration-200 transform hover:scale-105 active:scale-95"
        >
          <div className="relative flex items-center justify-center w-7 h-7 rounded-full bg-cyan-500/20 text-cyan-400">
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
            </svg>
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-cyan-400" />
          </div>

          <div className="text-right">
            <span className="block text-xs font-black text-white group-hover:text-cyan-200 transition-colors">
              گفت‌وگو و استعلام
            </span>
            <span className="block text-[10px] text-cyan-300/80 font-medium">
              پاسخگویی مستقیم مدیریت
            </span>
          </div>
        </button>
      </aside>

      {/* مدال ثبت سفارش و محاسبه قیمت بر اساس اولویت */}
      {isOrderModalOpen && (
        <OrderModal
          initialService={selectedService}
          services={services}
          onClose={handleCloseOrderModal}
          onOpenChatForOrder={(orderId, orderTitle) => {
            handleCloseOrderModal();
            handleOpenChat(orderId, orderTitle);
          }}
        />
      )}

      {/* مدال گفت‌وگوی زنده با مدیریت */}
      <UserChatModal
        isOpen={isChatModalOpen}
        onClose={() => {
          setIsChatModalOpen(false);
          setChatInitialOrderId(undefined);
          setChatInitialOrderTitle(undefined);
        }}
        initialOrderId={chatInitialOrderId}
        initialOrderTitle={chatInitialOrderTitle}
      />

      {/* مدال احراز هویت (ورود و ثبت‌نام سریع با شماره موبایل) */}
      <AuthModal />

      {/* پنل ادمین جهت کنترل سفارشات، قیمت‌ها و چت */}
      <AdminPanel onServicePriceUpdated={fetchServices} />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
