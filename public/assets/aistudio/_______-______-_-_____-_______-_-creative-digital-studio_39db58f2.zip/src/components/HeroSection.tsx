import React from 'react';
import { ScrollReveal } from './ScrollReveal';

interface HeroSectionProps {
  onOpenOrderModal: () => void;
  onOpenChat: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenOrderModal, onOpenChat }) => {
  const scrollToServices = () => {
    const el = document.getElementById('services');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const metrics = [
    { value: '+۱۴۰', label: 'پروژه موفق سازمانی و استارتاپی' },
    { value: '۹۹.۴٪', label: 'رضایت کارفرمایان و تحویل به‌موقع' },
    { value: '4K / 8K', label: 'رزولوشن و استانداردهای سینمایی' },
    { value: '۱۰۰٪', label: 'تحویل سورس و فایل‌های لایه‌باز' },
  ];

  return (
    <section aria-label="معرفی استودیو دیزاین و خدمات دیجیتال" className="relative pt-4 sm:pt-8 pb-12 sm:pb-16">
      
      {/* نشانگر بالای تیتر (Subtle Editorial Kicker) با ورود نرم از بالا */}
      <ScrollReveal delay={0.1} direction="down" distance={20} className="flex justify-center mb-5">
        <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 text-slate-300 text-xs font-medium backdrop-blur-md shadow-sm">
          <span className="w-2 h-2 rounded-full bg-cyan-400" />
          <span>استودیو تخصصی دیزاین، تیزرسازی و مهندسی دیجیتال</span>
          <span className="text-slate-600">·</span>
          <span className="text-cyan-300 font-mono text-[11px]">VERSION 2026</span>
        </div>
      </ScrollReveal>

      {/* تیتر اصلی با ابهت با ورود نرم از بالا */}
      <ScrollReveal delay={0.25} direction="down" distance={30} className="text-center max-w-4xl mx-auto px-4 mb-6">
        <h1
          className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.25] sm:leading-[1.2]"
          style={{ textWrap: 'balance' }}
        >
          خلق استانداردهای بصری و{' '}
          <span className="bg-gradient-to-l from-cyan-400 via-sky-300 to-cyan-200 bg-clip-text text-transparent">
            پلتفرم‌های دیجیتال
          </span>{' '}
          نسل بعد
        </h1>
      </ScrollReveal>

      {/* پاراگراف توضیحات ارزشی با ورود نرم از بالا */}
      <ScrollReveal delay={0.4} direction="down" distance={25} className="text-center max-w-2xl mx-auto px-4 mb-9">
        <p className="text-base sm:text-lg text-slate-300 leading-relaxed font-normal">
          تلفیق رندرینگ سه‌بعدی، تولید تیزرهای سینمایی، هویت بصری ممتاز و مهندسی نرم‌افزارهای مدرن تحت وب برای کسب‌وکارهایی که می‌خواهند فراتر از استانداردهای معمول بدرخشند.
        </p>
      </ScrollReveal>

      {/* دکمه‌های اقدام کلیدی با ابعاد ارگونومیک تاچ */}
      <ScrollReveal delay={0.55} direction="down" distance={20} className="flex flex-col sm:flex-row items-center justify-center gap-3.5 px-4 mb-14">
        <button
          onClick={scrollToServices}
          className="w-full sm:w-auto px-7 py-3.5 min-h-[48px] rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-sm shadow-[0_0_25px_rgba(0,229,255,0.35)] hover:shadow-[0_0_35px_rgba(0,229,255,0.5)] transition-all duration-200 flex items-center justify-center gap-2 transform active:scale-95"
        >
          <span>مشاهده خدمات و ثبت سفارش</span>
          <svg className="w-4 h-4 rotate-180" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <line x1="5" y1="12" x2="19" y2="12" />
            <polyline points="12 5 19 12 12 19" />
          </svg>
        </button>

        <button
          onClick={onOpenChat}
          className="w-full sm:w-auto px-6 py-3.5 min-h-[48px] rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/80 hover:border-cyan-500/40 font-bold text-sm transition-all duration-200 flex items-center justify-center gap-2 backdrop-blur-md active:scale-95"
        >
          <svg className="w-4 h-4 text-cyan-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          </svg>
          <span>مشاوره و استعلام مستقیم با مدیریت</span>
        </button>
      </ScrollReveal>

      {/* نوار اثبات آماری و شاخص‌های عددی استودیو */}
      <ScrollReveal delay={0.7} direction="down" distance={25} className="max-w-5xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 p-4 sm:p-5 rounded-3xl bg-[#080D19]/80 border border-slate-800/80 backdrop-blur-xl shadow-[0_15px_40px_rgba(0,0,0,0.4)]">
          {metrics.map((m, idx) => (
            <div
              key={idx}
              className={`p-3 text-center flex flex-col justify-center items-center ${
                idx !== metrics.length - 1 ? 'md:border-l md:border-slate-800/80' : ''
              }`}
            >
              <span className="text-xl sm:text-2xl lg:text-3xl font-black text-cyan-300 tracking-tight mb-1 dir-ltr inline-block">
                {m.value}
              </span>
              <span className="text-xs text-slate-400 leading-snug">
                {m.label}
              </span>
            </div>
          ))}
        </div>
      </ScrollReveal>

    </section>
  );
};
