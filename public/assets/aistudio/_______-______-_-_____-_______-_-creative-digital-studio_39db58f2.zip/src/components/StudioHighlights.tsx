import React from 'react';
import { ScrollReveal } from './ScrollReveal';

export const StudioHighlights: React.FC = () => {
  const highlights = [
    {
      num: '۰۱',
      title: 'خروجی استاندارد سینمایی (4K/8K)',
      desc: 'رندرینگ دقیق و اصلاح رنگ سینمایی DaVinci با تفکیک عمیق سایه‌روشن‌ها و غنای بصری هالیوودی.',
      detail: 'کیفیت بین‌المللی',
    },
    {
      num: '۰۲',
      title: 'پایبندی ۱۰۰٪ به موعد تحویل',
      desc: 'زمان‌بندی قطعی در پیش‌فاکتور با تضمین جبران خسارت؛ پروژه‌ها طبق تقویم دقیق به دست شما می‌رسد.',
      detail: 'سرعت و نظم',
    },
    {
      num: '۰۳',
      title: 'ارائه کامل فایل‌های لایه‌باز و سورس',
      desc: 'تمامی فایل‌های اصلی (PSD, AI, AfterEffects, React) بدون دریافت هزینه مازاد در پایان پروژه تحویل می‌شود.',
      detail: 'مالکیت بی‌قیدوشرط',
    },
    {
      num: '۰۴',
      title: 'مشاوره و پشتیبانی مستقیم مدیریت',
      desc: 'جلسات بازخوانی مستمر، رفع اصلاحات و همراهی اختصاصی تا رسیدن به نتیجه مطلوب و ایده‌آل برند شما.',
      detail: 'همراهی متعهدانه',
    },
  ];

  return (
    <section id="highlights" aria-label="شاخص‌های تمایز استودیو" className="my-16 max-w-7xl mx-auto px-4 sm:px-6 scroll-mt-20">
      
      {/* سرتیتر بخش با ظهور نرم از بالا */}
      <ScrollReveal direction="down" distance={25}>
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8 pb-4 border-b border-slate-800/80">
          <div>
            <span className="text-xs font-bold text-cyan-400 tracking-wider block mb-1">
              استانداردهای بنیادین تولید
            </span>
            <h2 className="text-xl sm:text-3xl font-black text-white">
              چرا برندهای پیشرو استودیو ما را برمی‌گزینند؟
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md leading-relaxed">
            فرآیند شفاف، تخصص در مرز فناوری‌های بصری و تعهد خلل‌ناپذیر به زمان‌بندی و کیفیت نهایی اثر.
          </p>
        </div>
      </ScrollReveal>

      {/* شبکه ۴ ستونه شاخص‌ها با ظهور پله‌ای و نرم */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {highlights.map((h, i) => (
          <ScrollReveal
            key={i}
            delay={i * 0.12}
            direction="down"
            distance={28}
          >
            <div className="h-full p-6 rounded-2xl bg-[#090F1D]/80 backdrop-blur-xl border border-slate-800/80 hover:border-cyan-500/40 transition-all duration-300 group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xl font-black text-cyan-400">
                    {h.num}
                  </span>
                  <span className="text-[11px] font-semibold text-slate-400 group-hover:text-cyan-300 transition-colors">
                    {h.detail}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white mb-2 group-hover:text-cyan-200 transition-colors">
                  {h.title}
                </h3>

                <p className="text-xs text-slate-300 leading-relaxed font-normal">
                  {h.desc}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-800/60 flex items-center gap-1.5 text-[11px] text-cyan-400 font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
                <span>تضمین رسمی کیفیت</span>
                <span>✓</span>
              </div>
            </div>
          </ScrollReveal>
        ))}
      </div>
    </section>
  );
};
