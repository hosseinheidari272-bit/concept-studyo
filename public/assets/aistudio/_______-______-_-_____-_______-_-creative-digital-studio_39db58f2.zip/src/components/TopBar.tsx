import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

interface TopBarProps {
  onOpenChat: () => void;
  onOpenOrderModal?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ onOpenChat, onOpenOrderModal }) => {
  const { user, isAdmin, openAuthModal, openAdminPanel, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [showContent, setShowContent] = useState(false);

  // انیمیشن کش‌آمدن و باز شدن نویگیشن بار از مرکز (الهام‌گرفته از موشن لوگوی ساند اپل موزیک)
  useEffect(() => {
    // شروع کش‌آمدن نویگیشن بار از مرکز پس از یک مکث کوتاه
    const timer1 = setTimeout(() => {
      setIsExpanded(true);
    }, 220);

    // ظهور نرم المان‌های متنی و دکمه‌ها همزمان با کامل شدن کشش
    const timer2 = setTimeout(() => {
      setShowContent(true);
    }, 550);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, []);

  const navLinks = [
    { label: 'خدمات استودیو', href: '#services' },
    { label: 'استانداردهای کیفیت', href: '#highlights' },
    { label: 'درباره استودیو', href: '#about' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="relative z-30 mb-8 sm:mb-12 flex justify-center w-full">
      
      {/* کانتینر کشسان نویگیشن با افکت پرتوهای کروماتیک سبک Apple Music Sound Logo */}
      <nav
        aria-label="ناوبری اصلی استودیو"
        style={{
          width: isExpanded ? '100%' : '60px',
          height: isExpanded ? 'auto' : '56px',
          minHeight: '56px',
          borderRadius: isExpanded ? '24px' : '28px',
          transition: 'width 0.9s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.9s cubic-bezier(0.16, 1, 0.3, 1), border-radius 0.9s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
        className={`relative flex items-center justify-between gap-4 sm:gap-8 px-4 sm:px-6 py-3.5 bg-[#080D19]/90 border border-slate-800/90 backdrop-blur-2xl overflow-hidden transition-all duration-300 mx-auto ${
          isExpanded
            ? 'shadow-[0_12px_40px_rgba(0,0,0,0.6),0_0_25px_rgba(0,229,255,0.12)] hover:border-slate-700/80'
            : 'shadow-[0_0_40px_rgba(0,229,255,0.6),inset_0_0_20px_rgba(0,229,255,0.3)]'
        }`}
      >
        {/* ۱. خط نوری و روبان کروماتیک متحرک هنگام کش‌آمدن از وسط */}
        <div
          style={{
            transform: isExpanded ? 'translateX(250%)' : 'translateX(-120%)',
            transition: 'transform 1.3s cubic-bezier(0.16, 1, 0.3, 1) 0.2s, opacity 0.8s ease 0.6s',
            opacity: showContent ? 0 : 0.85,
          }}
          className="absolute inset-0 pointer-events-none bg-gradient-to-r from-transparent via-cyan-400/35 to-blue-500/25 mix-blend-screen -skew-x-12"
          aria-hidden="true"
        />

        {/* حالت گوی مرکزی قبل از باز شدن کامل */}
        {!isExpanded && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-400 via-sky-200 to-blue-600 animate-spin-slow opacity-90 blur-[1px]" />
            <div className="w-4 h-4 rounded-full bg-white absolute shadow-[0_0_12px_#00e5ff]" />
          </div>
        )}

        {/* محتوای داخلی نویگیشن که پس از کش‌آمدن با ترنزیشن نرم ظاهر می‌شوند */}
        {/* ۱. زون ۱: نشان و نام برند (Brand Element) */}
        <div
          style={{
            opacity: showContent ? 1 : 0,
            transform: showContent ? 'translateX(0)' : 'translateX(18px)',
            filter: showContent ? 'blur(0px)' : 'blur(4px)',
            transition: 'opacity 0.6s ease 0.2s, transform 0.6s cubic-bezier(0.16, 1, 0.3, 1) 0.2s, filter 0.6s ease 0.2s',
          }}
          className="flex items-center gap-3 shrink-0"
        >
          <a
            href="/"
            className="flex items-center gap-2.5 text-white group focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500/25 via-blue-600/20 to-slate-900 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shadow-[0_0_16px_rgba(0,229,255,0.3)] group-hover:scale-105 transition-transform duration-200">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                <polygon points="12 2 2 7 12 12 22 7 12 2" />
                <polyline points="2 17 12 22 22 17" />
                <polyline points="2 12 12 17 22 12" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="text-base sm:text-lg font-black tracking-tight text-white group-hover:text-cyan-300 transition-colors">
                CONCEPT STUDIO
              </span>
              <span className="text-[10px] text-slate-400 font-medium">
                استودیو دیزاین و مهندسی دیجیتال
              </span>
            </div>
          </a>
        </div>

        {/* ۲. زون ۲: پیوندهای ناوبری در دسکتاپ */}
        <div
          style={{
            opacity: showContent ? 1 : 0,
            transform: showContent ? 'translateY(0)' : 'translateY(-12px)',
            filter: showContent ? 'blur(0px)' : 'blur(4px)',
            transition: 'opacity 0.6s ease 0.3s, transform 0.6s cubic-bezier(0.16, 1, 0.3, 1) 0.3s, filter 0.6s ease 0.3s',
          }}
          className="hidden lg:flex items-center gap-7 text-xs font-semibold text-slate-300"
        >
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => handleNavClick(e, link.href)}
              className="hover:text-cyan-300 transition-colors py-1 whitespace-nowrap shrink-0 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-cyan-400 after:scale-x-0 hover:after:scale-x-100 after:transition-transform"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* ۳. زون ۳: عملیات ورود، ثبت‌نام، پنل ادمین و مشاوره */}
        <div
          style={{
            opacity: showContent ? 1 : 0,
            transform: showContent ? 'translateX(0)' : 'translateX(-18px)',
            filter: showContent ? 'blur(0px)' : 'blur(4px)',
            transition: 'opacity 0.6s ease 0.25s, transform 0.6s cubic-bezier(0.16, 1, 0.3, 1) 0.25s, filter 0.6s ease 0.25s',
          }}
          className="flex items-center gap-2.5 shrink-0"
        >
          {/* دکمه گفت‌وگو و ارتباط سریع */}
          <button
            onClick={onOpenChat}
            title="ارسال پیام و استعلام مستقیم"
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/80 hover:border-cyan-500/50 text-xs font-bold transition-all active:scale-95 shadow-sm"
          >
            <svg className="w-3.5 h-3.5 text-cyan-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
            </svg>
            <span>مشاوره و گفت‌وگو</span>
          </button>

          {user ? (
            /* کاربر احراز هویت شده */
            <div className="flex items-center gap-2 bg-slate-900/95 border border-slate-800 px-2.5 sm:px-3 py-1.5 rounded-xl shadow-inner">
              <div className="flex items-center gap-1.5 text-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="font-bold text-slate-200 hidden md:inline">{user.fullName || user.username}</span>
              </div>

              {isAdmin && (
                <button
                  onClick={openAdminPanel}
                  className="px-2.5 py-1 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-[0_0_12px_rgba(0,229,255,0.3)] transition-all active:scale-95"
                >
                  ⚡ پنل ادمین
                </button>
              )}

              <button
                onClick={logout}
                title="خروج از حساب"
                className="px-2 py-1 text-xs text-slate-400 hover:text-rose-300 transition-colors"
              >
                خروج
              </button>
            </div>
          ) : (
            /* دسکتاپ: دکمه‌های ورود و ثبت‌نام */
            <div className="hidden sm:flex items-center gap-1.5 p-1 rounded-xl bg-slate-950/70 border border-slate-800">
              <button
                onClick={() => openAuthModal('login')}
                className="px-3.5 py-1.5 min-h-[36px] rounded-lg bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/60 text-xs font-bold transition-all active:scale-95"
              >
                ورود
              </button>
              <button
                onClick={() => openAuthModal('register')}
                className="px-3.5 py-1.5 min-h-[36px] rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-black shadow-[0_0_15px_rgba(0,229,255,0.3)] transition-all active:scale-95"
              >
                ثبت‌نام
              </button>
            </div>
          )}

          {/* کلید همبرگری موبایل با ابعاد استاندارد تاچ (Mobile-First) */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="باز کردن منوی موبایل"
            aria-expanded={isMobileMenuOpen}
            className="lg:hidden w-11 h-11 min-w-[44px] rounded-xl bg-slate-900/90 border border-slate-700/80 hover:border-cyan-400/50 flex flex-col items-center justify-center gap-1.5 text-slate-200 transition-colors focus:outline-none"
          >
            <span className={`w-5 h-0.5 bg-current transition-transform duration-200 ${isMobileMenuOpen ? 'rotate-45 translate-y-2' : ''}`} />
            <span className={`w-5 h-0.5 bg-current transition-opacity duration-200 ${isMobileMenuOpen ? 'opacity-0' : ''}`} />
            <span className={`w-5 h-0.5 bg-current transition-transform duration-200 ${isMobileMenuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
          </button>
        </div>
      </nav>

      {/* منوی کشویی موبایل */}
      {isMobileMenuOpen && (
        <div
          style={{ animation: 'fadeInDown 0.25s ease-out forwards' }}
          className="lg:hidden absolute top-full left-0 right-0 mt-2 p-4 rounded-2xl bg-[#080D19] border border-cyan-500/30 shadow-[0_15px_50px_rgba(0,0,0,0.8)] backdrop-blur-2xl space-y-3"
        >
          {!user && (
            <div className="grid grid-cols-2 gap-2 pb-3 border-b border-slate-800">
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  openAuthModal('login');
                }}
                className="py-3 min-h-[46px] rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold border border-slate-700 text-center"
              >
                ورود به حساب
              </button>
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  openAuthModal('register');
                }}
                className="py-3 min-h-[46px] rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-black shadow-[0_0_15px_rgba(0,229,255,0.3)] text-center"
              >
                ثبت‌نام جدید
              </button>
            </div>
          )}

          <div className="flex flex-col gap-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="px-4 py-3 min-h-[48px] rounded-xl bg-slate-900/60 hover:bg-slate-800 text-slate-200 hover:text-cyan-300 text-sm font-semibold flex items-center justify-between transition-colors"
              >
                <span>{link.label}</span>
                <span className="text-slate-500 text-xs font-mono">←</span>
              </a>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-800 flex flex-col gap-2">
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenChat();
              }}
              className="w-full py-3.5 min-h-[48px] rounded-xl bg-slate-900 border border-cyan-500/30 text-cyan-300 text-xs font-bold flex items-center justify-center gap-2"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
              <span>گفت‌وگو و ارتباط با مدیریت استودیو</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
