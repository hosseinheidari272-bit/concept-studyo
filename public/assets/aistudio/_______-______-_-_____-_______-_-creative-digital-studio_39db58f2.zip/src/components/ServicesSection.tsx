import React, { useState } from 'react';
import { ServiceCategory, ServiceItem } from '../types';
import { studioServices } from '../data/services';
import { ServiceCard } from './ServiceCard';
import { ScrollReveal } from './ScrollReveal';

interface ServicesSectionProps {
  services?: ServiceItem[];
  onSelectService: (service: ServiceItem) => void;
  onOpenChatForService?: (service: ServiceItem) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  services = studioServices,
  onSelectService,
  onOpenChatForService,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategory>('all');

  const categories = [
    { id: 'all', label: 'تمامی ۹ خدمت', count: services.length },
    { id: 'design', label: 'طراحی، رندر ۳D و گرافیک', count: services.filter(s => s.category === 'design').length },
    { id: 'video_audio', label: 'سینما، موشن و صدا', count: services.filter(s => s.category === 'video_audio').length },
    { id: 'dev_automation', label: 'وب‌سایت و هوش مصنوعی', count: services.filter(s => s.category === 'dev_automation').length },
  ];

  const filteredServices = selectedCategory === 'all'
    ? services
    : services.filter((s) => s.category === selectedCategory);

  return (
    <section id="services" className="relative py-16 sm:py-20 scroll-mt-14">
      
      {/* هدر بخش خدمات با ورود نرم از بالا */}
      <ScrollReveal direction="down" distance={25} className="text-center max-w-2xl mx-auto mb-10 px-4">
        <span className="text-xs font-bold text-cyan-400 tracking-wider block mb-2 uppercase">
          اکوسیستم خدمات تخصصی
        </span>
        <h2 className="text-2xl sm:text-4xl font-black text-white mb-3 tracking-tight">
          تعرفه‌های شفاف و خدمات استودیو
        </h2>
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-normal">
          هر پکیج با تعهد کامل به استانداردهای سینمایی، تحویل فایل‌های لایه‌باز و بدون هزینه‌های پنهان اجرا می‌شود.
        </p>
      </ScrollReveal>

      {/* کنترل سگمنتد دسته‌بندی‌ها با ورود نرم */}
      <ScrollReveal delay={0.15} direction="down" distance={20} className="flex items-center justify-center flex-wrap gap-2 mb-10 px-4">
        <div className="p-1 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center flex-wrap gap-1 shadow-inner">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as ServiceCategory)}
                className={`px-3.5 py-2 min-h-[40px] rounded-xl text-xs font-bold transition-all duration-200 flex items-center gap-2 whitespace-nowrap active:scale-95 ${
                  isActive
                    ? 'bg-cyan-500 text-slate-950 shadow-[0_0_15px_rgba(0,229,255,0.35)] font-black'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <span>{cat.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-md font-mono ${
                    isActive ? 'bg-slate-950/20 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {cat.count}
                </span>
              </button>
            );
          })}
        </div>
      </ScrollReveal>

      {/* گرید ۳ ستونه کارت‌های خدمات با انیمیشن ورود نرم پله‌ای از بالا به پایین */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto px-4 sm:px-6">
        {filteredServices.map((service, idx) => (
          <ScrollReveal
            key={service.id}
            delay={0.1 + (idx % 3) * 0.12}
            direction="down"
            distance={30}
          >
            <ServiceCard
              service={service}
              onSelect={onSelectService}
              onOpenChatWithService={onOpenChatForService}
            />
          </ScrollReveal>
        ))}
      </div>
    </section>
  );
};
