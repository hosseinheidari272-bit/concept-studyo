import React, { useRef, useEffect, useState, ReactNode } from 'react';

interface ScrollRevealProps {
  children: ReactNode;
  delay?: number;
  direction?: 'down' | 'up' | 'none';
  className?: string;
  distance?: number;
}

/**
 * کامپوننت افکت ظهور نرم هنگام اسکرول (Pure High-Performance Scroll Reveal)
 * ویژگی‌ها:
 * ۱. استفاده از Intersection Observer بومی مرورگر (فوق‌سریع و بدون باگ)
 * ۲. انیمیشن نرم از بالا به پایین با بلور و تغییر مکان سه‌بعدی
 * ۳. اجرای ۶۰ فریم پایدار بر روی پردازنده گرافیکی (GPU Compositor)
 */
export const ScrollReveal: React.FC<ScrollRevealProps> = ({
  children,
  delay = 0,
  direction = 'down', // پیش‌فرض از بالا به پایین بر اساس خواسته کاربر
  className = '',
  distance = 28,
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    // بررسی فوری اگر المن در ویوپورت قرار دارد
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight * 0.9) {
      setIsVisible(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(el);
        }
      },
      {
        threshold: 0.08,
        rootMargin: '0px 0px -40px 0px',
      }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const yOffset = direction === 'down' ? -distance : direction === 'up' ? distance : 0;

  return (
    <div
      ref={ref}
      style={{
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? 'translateY(0)' : `translateY(${yOffset}px)`,
        filter: isVisible ? 'blur(0px)' : 'blur(6px)',
        transition: `opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${delay}s, transform 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${delay}s, filter 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${delay}s`,
        willChange: 'opacity, transform, filter',
      }}
      className={className}
    >
      {children}
    </div>
  );
};
