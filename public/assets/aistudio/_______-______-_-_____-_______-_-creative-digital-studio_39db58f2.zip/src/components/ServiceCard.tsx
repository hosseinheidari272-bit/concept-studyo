import React from 'react';
import { ServiceItem } from '../types';
import { formatPersianPrice, calculateDiscount, toPersianDigits } from '../utils/persianDate';

interface ServiceCardProps {
  service: ServiceItem;
  onSelect: (service: ServiceItem) => void;
  onOpenChatWithService?: (service: ServiceItem) => void;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({ service, onSelect, onOpenChatWithService }) => {
  const hasDiscount = (service.discountPercent || 0) > 0;
  const discountedPrice = hasDiscount
    ? calculateDiscount(service.startingPrice, service.discountPercent!)
    : service.startingPrice;

  // رندر طرح بصری منحصربه‌فرد برای هر خدمت (Bespoke Visual Canvas for Each Discipline)
  const renderArtBanner = () => {
    switch (service.id) {
      case 'photo-design':
        return (
          <div className="relative h-28 w-full rounded-2xl bg-gradient-to-br from-blue-950/60 via-slate-900 to-black border border-cyan-500/20 p-3 overflow-hidden flex items-center justify-between">
            <div className="space-y-1 z-10">
              <span className="text-[10px] font-mono text-cyan-400 font-bold block">8K PHOTO ART</span>
              <span className="text-xs font-bold text-white block">فتومونتاژ و روتوش هالیوودی</span>
            </div>
            <div className="relative w-16 h-16 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300">
              <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <circle cx="8.5" cy="8.5" r="1.5" />
                <polyline points="21 15 16 10 5 21" />
              </svg>
            </div>
          </div>
        );
      case 'video-editing':
        return (
          <div className="relative h-28 w-full rounded-2xl bg-gradient-to-br from-indigo-950/60 via-slate-900 to-black border border-indigo-500/20 p-3 overflow-hidden flex items-center justify-between">
            <div className="space-y-1 z-10">
              <span className="text-[10px] font-mono text-cyan-400 font-bold block">CINEMATIC 4K</span>
              <span className="text-xs font-bold text-white block">اصلاح رنگ و موشن‌گرافیک</span>
            </div>
            <div className="relative w-16 h-16 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300">
              <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
                <polygon points="23 7 16 12 23 17 23 7" />
                <rect x="1" y="5" width="15" height="14" rx="2" />
              </svg>
            </div>
          </div>
        );
      case 'post-banner-design':
        return (
          <div className="relative h-28 w-full rounded-2xl bg-gradient-to-br from-sky-950/60 via-slate-900 to-black border border-sky-500/20 p-3 overflow-hidden flex items-center justify-between">
            <div className="space-y-1 z-10">
              <span className="text-[10px] font-mono text-cyan-400 font-bold block">AD CAMPAIGN</span>
              <span className="text-xs font-bold text-white block">بنرها و کاورهای با نرخ کلیک بالا</span>
            </div>
            <div className="relative w-16 h-16 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300">
              <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <line x1="3" y1="9" x2="21" y2="9" />
                <line x1="9" y1="21" x2="9" y2="9" />
              </svg>
            </div>
          </div>
        );
      case 'product-3d-commercial':
        return (
          <div className="relative h-28 w-full rounded-2xl bg-gradient-to-br from-cyan-950/60 via-slate-900 to-black border border-cyan-500/30 p-3 overflow-hidden flex items-center justify-between">
            <div className="space-y-1 z-10">
              <span className="text-[10px] font-mono text-cyan-400 font-bold block">3D PHOTOREAL</span>
              <span className="text-xs font-bold text-white block">رندر سه‌بعدی محصولات و موکاپ</span>
            </div>
            <div className="relative w-16 h-16 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300">
              <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
                <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
                <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
                <line x1="12" y1="22.08" x2="12" y2="12" />
              </svg>
            </div>
          </div>
        );
      case 'luxury-web-development':
        return (
          <div className="relative h-28 w-full rounded-2xl bg-gradient-to-br from-blue-950/60 via-slate-900 to-black border border-cyan-500/30 p-3 overflow-hidden flex items-center justify-between">
            <div className="space-y-1 z-10">
              <span className="text-[10px] font-mono text-cyan-400 font-bold block">NEXT-GEN WEB</span>
              <span className="text-xs font-bold text-white block">توسعه سایت و لندینگ لوکس</span>
            </div>
            <div className="relative w-16 h-16 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300">
              <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
                <polyline points="16 18 22 12 16 6" />
                <polyline points="8 6 2 12 8 18" />
              </svg>
            </div>
          </div>
        );
      default:
        return (
          <div className="relative h-28 w-full rounded-2xl bg-gradient-to-br from-slate-900 via-slate-950 to-black border border-slate-800 p-3 overflow-hidden flex items-center justify-between">
            <div className="space-y-1 z-10">
              <span className="text-[10px] font-mono text-cyan-400 font-bold block">AI & AUTOMATION</span>
              <span className="text-xs font-bold text-white block">{service.subtitle}</span>
            </div>
            <div className="relative w-16 h-16 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300">
              <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
                <polygon points="12 2 2 7 12 12 22 7 12 2" />
                <polyline points="2 17 12 22 22 17" />
                <polyline points="2 12 12 17 22 12" />
              </svg>
            </div>
          </div>
        );
    }
  };

  return (
    <article
      className="relative rounded-3xl bg-[#090F1C]/90 border border-slate-800/80 hover:border-cyan-500/40 p-5 sm:p-6 flex flex-col justify-between overflow-hidden shadow-[0_15px_40px_rgba(0,0,0,0.5)] hover:shadow-[0_20px_50px_rgba(0,180,255,0.14)] transition-all duration-300 group"
    >
      <div>
        {/* ۱. بنر بصری اختصاصی خدمت */}
        <div className="mb-4">
          {renderArtBanner()}
        </div>

        {/* ۲. هدر متنی و شماره خدمت */}
        <div className="flex items-start justify-between gap-3 mb-2">
          <div>
            <span className="text-[11px] font-mono font-bold text-cyan-400 tracking-wider block mb-0.5">
              SERVICE #{service.number}
            </span>
            <h3 className="text-base sm:text-lg font-black text-white group-hover:text-cyan-200 transition-colors">
              {service.title}
            </h3>
          </div>

          {service.popular && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30 shrink-0">
              ویژه و پرطرفدار
            </span>
          )}
        </div>

        {/* ۳. متن توضیحات */}
        <p className="text-xs text-slate-300 leading-relaxed font-normal mb-4 min-h-[44px]">
          {service.description}
        </p>

        {/* ۴. برچسب‌ها با شیوه تمیز متنی بدون کپسول‌های سنگین */}
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-400 mb-4 pb-3 border-b border-slate-800/60">
          {service.tags.map((tag, idx) => (
            <React.Fragment key={idx}>
              <span className="text-slate-300">#{tag}</span>
              {idx < service.tags.length - 1 && <span className="text-slate-600">·</span>}
            </React.Fragment>
          ))}
        </div>

        {/* ۵. چک‌لیست اقلام تحویلی */}
        <div className="space-y-1.5 mb-5">
          <span className="text-[11px] font-bold text-slate-400 block mb-1">اقلام تحویلی تضمین‌شده:</span>
          {service.deliverables.map((item, idx) => (
            <div key={idx} className="flex items-center gap-2 text-xs text-slate-300">
              <span className="text-cyan-400 text-xs">✓</span>
              <span>{item}</span>
            </div>
          ))}
        </div>
      </div>

      {/* بخش پایین کارت: قیمت‌گذاری و دکمه‌های اقدام */}
      <div className="pt-4 border-t border-slate-800/80">
        <div className="flex items-center justify-between gap-2 mb-4">
          <div>
            <span className="text-[11px] text-slate-400 block">شروع قیمت از:</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg sm:text-xl font-black text-white tabular-nums">
                {formatPersianPrice(discountedPrice)}
              </span>
              {hasDiscount && (
                <span className="text-xs text-slate-500 line-through tabular-nums">
                  {formatPersianPrice(service.startingPrice)}
                </span>
              )}
            </div>
          </div>

          <div className="text-left">
            <span className="text-[11px] text-slate-400 block">زمان تحویل:</span>
            <span className="text-xs font-bold text-cyan-300">
              {service.deliveryTime}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onSelect(service)}
            className="flex-1 py-3 min-h-[46px] rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-[0_0_15px_rgba(0,229,255,0.25)] hover:shadow-[0_0_20px_rgba(0,229,255,0.4)] transition-all flex items-center justify-center gap-1.5 active:scale-95"
          >
            <span>ثبت سفارش / استعلام فوری</span>
            <svg className="w-3.5 h-3.5 rotate-180" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <line x1="5" y1="12" x2="19" y2="12" />
              <polyline points="12 5 19 12 12 19" />
            </svg>
          </button>

          {onOpenChatWithService && (
            <button
              onClick={() => onOpenChatWithService(service)}
              title="گفت‌وگو درباره این خدمت"
              className="p-3 min-h-[46px] min-w-[46px] rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-700/70 hover:border-cyan-500/40 transition-colors flex items-center justify-center active:scale-95"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
            </button>
          )}
        </div>
      </div>
    </article>
  );
};
