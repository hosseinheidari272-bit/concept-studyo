import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

/**
 * پس‌زمینه سه‌بعدی امواج نوری سیال و پرتوهای آبی (Sixfold 3D Glowing Wave Lines)
 * بدون پیکسل‌های مربعی شکل با استفاده از خطوط و مش یکنواخت نئونی
 */
export const ThreeHeroCanvas: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || 600;

    // ۱. صحنه و دوربین
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
    camera.position.set(0, 3, 24);

    // ۲. رندرر
    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: false, // سبک و روان
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, Math.min(height, 800));
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.25));
    container.appendChild(renderer.domElement);

    // ۳. امواج خطی سیال نئونی (Multi-layered Sinusoidal Ribbon Lines)
    const lineGroup = new THREE.Group();
    scene.add(lineGroup);

    const waveLines: { line: THREE.Line; basePoints: THREE.Vector3[]; speed: number; amp: number }[] = [];
    const lineColors = [0x00E5FF, 0x0088FF, 0x0055EE, 0x38BDF8, 0x0EA5E9];
    const numLines = 8;
    const segments = 45;
    const length = 44;

    for (let l = 0; l < numLines; l++) {
      const points: THREE.Vector3[] = [];
      const basePoints: THREE.Vector3[] = [];
      const yOffset = (l - numLines / 2) * 1.1 - 4;
      const zOffset = (l - numLines / 2) * 1.5;

      for (let i = 0; i <= segments; i++) {
        const x = (i / segments - 0.5) * length;
        const pt = new THREE.Vector3(x, yOffset, zOffset);
        points.push(pt.clone());
        basePoints.push(pt.clone());
      }

      const geometry = new THREE.BufferGeometry().setFromPoints(points);
      const material = new THREE.LineBasicMaterial({
        color: lineColors[l % lineColors.length],
        transparent: true,
        opacity: 0.25 + (l / numLines) * 0.35,
      });

      const line = new THREE.Line(geometry, material);
      lineGroup.add(line);

      waveLines.push({
        line,
        basePoints,
        speed: 0.7 + l * 0.12,
        amp: 1.1 + l * 0.18,
      });
    }

    // ۴. شبکه افقی موج‌دار ظریف در عمق
    const gridCols = 24;
    const gridRows = 16;
    const gridGeo = new THREE.PlaneGeometry(50, 26, gridCols, gridRows);
    gridGeo.rotateX(-Math.PI / 2.2);
    const gridMat = new THREE.MeshBasicMaterial({
      color: 0x0055aa,
      wireframe: true,
      transparent: true,
      opacity: 0.08,
    });
    const gridMesh = new THREE.Mesh(gridGeo, gridMat);
    gridMesh.position.set(0, -6, -5);
    scene.add(gridMesh);

    // موس با Throttling برای عملکرد فوق‌العاده سریع
    let mouseX = 0;
    let mouseY = 0;
    let mouseTicking = false;
    const handleMouseMove = (e: MouseEvent) => {
      if (!mouseTicking) {
        window.requestAnimationFrame(() => {
          mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
          mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
          mouseTicking = false;
        });
        mouseTicking = true;
      }
    };
    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    let animationFrameId: number;
    let clock = new THREE.Clock();
    let isVisible = true;

    // متوقف کردن حلقه رندر وقتی کاربر اسکرول کرده و هیرو خارج از کادر است
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          isVisible = entry.isIntersecting;
        });
      },
      { threshold: 0.05 }
    );
    observer.observe(container);

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (!isVisible) return; // توقف کامل مصرف GPU در زمان اسکرول به پایین

      const elapsed = clock.getElapsedTime();

      // انیمیشن موج‌های نوری سیال
      waveLines.forEach((item, lIdx) => {
        const posAttr = item.line.geometry.attributes.position as THREE.BufferAttribute;
        const positions = posAttr.array as Float32Array;

        for (let i = 0; i <= segments; i++) {
          const base = item.basePoints[i];
          const wavePhase = base.x * 0.18 + elapsed * item.speed + lIdx * 0.4;
          const y = base.y + Math.sin(wavePhase) * item.amp + Math.cos(base.x * 0.1 + elapsed * 0.5) * 0.6;
          const z = base.z + Math.cos(wavePhase * 0.8) * 0.8;

          positions[i * 3 + 1] = y;
          positions[i * 3 + 2] = z;
        }
        posAttr.needsUpdate = true;
      });

      // نرم‌سازی چرخش بر اساس موس
      lineGroup.rotation.y = THREE.MathUtils.lerp(lineGroup.rotation.y, mouseX * 0.15, 0.04);
      lineGroup.rotation.x = THREE.MathUtils.lerp(lineGroup.rotation.x, -mouseY * 0.08, 0.04);

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = Math.min(container.clientHeight || 600, 800);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize, { passive: true });

    return () => {
      observer.disconnect();
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      waveLines.forEach((w) => {
        w.line.geometry.dispose();
        (w.line.material as THREE.Material).dispose();
      });
      gridGeo.dispose();
      gridMat.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="absolute top-0 left-0 right-0 h-[700px] pointer-events-none z-0 overflow-hidden"
      style={{ contain: 'paint' }}
      aria-hidden="true"
    />
  );
};
