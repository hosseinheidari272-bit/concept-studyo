import React from 'react';
import { ScrollReveal } from './ScrollReveal';

interface FooterProps {
  onOpenChat?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenChat }) => {
  return (
    <footer id="about" className="relative z-10 mt-24 pt-14 pb-16 border-t border-slate-900 bg-[#060A14] backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <ScrollReveal direction="down" distance={25}>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 sm:gap-10 mb-12">
            
            {/* ستون ۱ و ۲: معرفی استودیو */}
            <div className="md:col-span-2 space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                    <polygon points="12 2 2 7 12 12 22 7 12 2" />
                    <polyline points="2 17 12 22 22 17" />
                    <polyline points="2 12 12 17 22 12" />
                  </svg>
                </div>
                <span className="text-lg font-black text-white">CONCEPT STUDIO</span>
              </div>

            <p className="text-sm text-slate-300 leading-relaxed max-w-lg font-normal">
              استودیو تخصصی طراحی گرافیک، تیزرسازی تبلیغاتی، مدل‌سازی سه‌بعدی و توسعه راهکارهای هوش مصنوعی و وب مدرن. ما هویت بصری کسب‌وکارها را با بالاترین استانداردهای کیفی جهانی بازآفرینی می‌کنیم.
            </p>

            <div className="flex items-center gap-3 pt-1 text-xs text-slate-400">
              <span className="text-slate-300">تهران و پروژه‌های بین‌المللی</span>
              <span>·</span>
              <span className="text-cyan-400 font-bold">پشتیبانی متعهدانه و شفاف</span>
            </div>
          </div>

          {/* ستون ۳: دسته‌بندی خدمات */}
          <div className="space-y-3 text-sm">
            <span className="font-bold text-white block mb-3 text-xs tracking-wider uppercase">
              حوزه‌های فعالیت
            </span>
            <ul className="space-y-2.5 text-slate-400 text-xs sm:text-sm">
              <li>
                <a href="#services" className="hover:text-cyan-300 transition-colors">
                  طراحی عکس و کامپوزیت 8K
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-cyan-300 transition-colors">
                  ساخت و اصلاح رنگ تیزر سینمایی
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-cyan-300 transition-colors">
                  رندرهای سه‌بعدی محصولات
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-cyan-300 transition-colors">
                  توسعه وب‌سایت‌های لوکس و سریع
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-cyan-300 transition-colors">
                  اتوماسیون کسب‌وکار و سیستم‌های هوشمند
                </a>
              </li>
            </ul>
          </div>

          {/* ستون ۴: ارتباط مستقیم */}
          <div className="space-y-3 text-sm">
            <span className="font-bold text-white block mb-3 text-xs tracking-wider uppercase">
              ارتباط مستقیم با مدیریت
            </span>
            <p className="text-xs text-slate-300 leading-relaxed">
              جهت دریافت مشاوره اولیه، هماهنگی جلسات فنی و ارسال بریف پروژه می‌توانید مستقیماً با ما در ارتباط باشید.
            </p>

            <div className="pt-2 flex flex-col gap-2.5">
              {onOpenChat && (
                <button
                  onClick={onOpenChat}
                  className="px-4 py-2.5 min-h-[44px] rounded-xl bg-slate-900 hover:bg-slate-800 border border-cyan-500/30 text-cyan-300 hover:text-cyan-200 text-xs font-bold transition-colors flex items-center justify-between"
                >
                  <span>شروع گفت‌وگوی آنلاین</span>
                  <span className="text-xs">💬</span>
                </button>
              )}
              <span className="text-xs text-slate-400 font-mono">
                ایمیل: info@sixfold-studio.ir
              </span>
            </div>
          </div>

          </div>

          {/* کپی‌رایت تمیز و حرفه‌ای */}
          <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <span>
              © ۲۰۲۶ استودیو کانسپت (Concept Studio). تمامی حقوق مادی و معنوی محفوظ است.
            </span>
            <div className="flex items-center gap-4 text-xs text-slate-400">
              <span>طراحی با استانداردهای مدرن فرانت‌اند</span>
              <span>·</span>
              <span className="text-cyan-400 font-bold">نسخه پایدار</span>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </footer>
  );
};
