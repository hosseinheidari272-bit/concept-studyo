import { ServiceItem } from '../types';

export const studioServices: ServiceItem[] = [
  {
    id: 'photo-design',
    number: '01',
    title: 'طراحی عکس و کامپوزیت حرفه‌ای',
    subtitle: 'Photo Design & Visual Art',
    description: 'خلق، روتوش حرفه‌ای و دستکاری خلاقانه تصاویر با جزئیات خیره‌کننده، نورپردازی سینمایی و تکنیک‌های پیشرفته فتومونتاژ.',
    category: 'design',
    tags: ['فتومونتاژ پیشرفته', 'روتوش هالیوودی', 'رنگ‌آمیزی اختصاصی', 'وضوح 8K'],
    startingPrice: 3800000,
    deliveryTime: '۲ تا ۳ روز کاری',
    deliverables: ['فایل لایه‌باز PSD', 'خروجی TIFF و JPG بدون افت کیفیت', '۲ دور ادیت رایگان', 'لایسنس تجاری کامل']
  },
  {
    id: 'video-editing',
    number: '02',
    title: 'ساخت و ادیت ویدیوی سینمایی',
    subtitle: 'Cinematic Video & Motion',
    description: 'تدوین ریتمیک، اصلاح رنگ سینمایی (Color Grading)، موشن‌گرافیک و جلوه‌های ویژه بصری (VFX) برای جذب حداکثری مخاطب.',
    category: 'video_audio',
    tags: ['اصلاح رنگ DaVinci', 'موشن‌گرافیک 3D', 'جلوه‌های ویژه بصری', 'طراحی سانددیزاین'],
    startingPrice: 7500000,
    deliveryTime: '۳ تا ۵ روز کاری',
    popular: true,
    deliverables: ['خروجی 4K UHD برای یوتیوب و اینستاگرام', 'سانددیزاین و موسیقی ارجینال', 'تیتراژ و زیرنویس اختصاصی']
  },
  {
    id: 'post-banner-design',
    number: '03',
    title: 'طراحی پست و بنر تبلیغاتی',
    subtitle: 'Ad Creatives & Social Media Kits',
    description: 'طراحی گرافیک مدرن برای کمپین‌های تبلیغاتی، کاورها و اسلایدهای تعاملی با هویت بصری منحصربه‌فرد و منطبق بر روانشناسی رنگ.',
    category: 'design',
    tags: ['بنرهای کلیکی (CTR بالا)', 'اسلایدر تعاملی', 'تمپلیت شبکه اجتماعی', 'هویت بصری'],
    startingPrice: 2200000,
    deliveryTime: '۲۴ تا ۴۸ ساعت',
    deliverables: ['سایزهای استاندارد استوری و پست', 'فایل برداری وکتور و PSD', 'راهنمای فونت و پالت رنگ']
  },
  {
    id: 'product-3d-commercial',
    number: '04',
    title: 'طراحی تصاویر تبلیغاتی محصولات',
    subtitle: 'Commercial 3D & Product Renders',
    description: 'صحنه‌آرایی دیجیتال، رندرینگ استودیویی و شبیه‌سازی متریال محصولات برای افزایش فوق‌العاده نرخ تبدیل و فروش آنلاین در مارکت‌پلیس‌ها.',
    category: 'design',
    tags: ['رندر سه‌بعدی فوتورئال', 'نورپردازی استودیویی', 'مدل‌سازی دقیق کالا', 'بسته‌بندی و موکاپ'],
    startingPrice: 6000000,
    deliveryTime: '۳ تا ۴ روز کاری',
    popular: true,
    deliverables: ['زوایای ۳۶۰ درجه محصول', 'رندر ترنسپرنت بدون پس‌زمینه', 'فایل رندر 3D با رزولوشن چاپ']
  },
  {
    id: 'social-media-growth',
    number: '05',
    title: 'تولید محتوا برای شبکه اجتماعی',
    subtitle: 'Full Social Media Strategy & Production',
    description: 'تدوین استراتژی محتوایی، سناریونویسی قلاب‌دار و تولید محتوای وایرال متناسب با الگوریتم‌های روز پلتفرم‌ها برای جذب مخاطب وفادار.',
    category: 'video_audio',
    tags: ['سناریونویسی ریلز', 'تقویم محتوایی ماهانه', 'تولید وایرال', 'بهینه‌سازی الگوریتم'],
    startingPrice: 12000000,
    deliveryTime: 'پروژه‌های ماهیانه یا هفتگی',
    deliverables: ['تقویم محتوایی ۳۰ روزه', '۱۲ ریلز ادیت شده آماده انتشار', 'کپشن‌نویسی اصولی و هشتگ‌های هدفمند']
  },
  {
    id: 'voice-synthesis-audio',
    number: '06',
    title: 'تبدیل متن به صدا و تولید محتوای صوتی',
    subtitle: 'AI Voice Synthesis & Studio Audio',
    description: 'نریشن و صداگذاری فوق‌طبیعی با لحن‌های متنوع، مهندسی صدا، پاکسازی نویز، ساخت پادکست‌های شرکتی و کتاب صوتی با بالاترین وفاداری صوتی.',
    category: 'video_audio',
    tags: ['نریشن فوق‌واقعی', 'میکس و مسترینگ صدا', 'پادکست اختصاصی', 'افکت‌های ساند‌افکت'],
    startingPrice: 3200000,
    deliveryTime: '۲۴ تا ۴۸ ساعت',
    deliverables: ['فایل صوتی استریو WAV با کیفیت استودیو', 'هماهنگ‌سازی زمان‌بندی با ویدیو', 'نسخه کوتاه تیزری']
  },
  {
    id: 'luxury-web-development',
    number: '07',
    title: 'طراحی سایت و لندینگ پیج اختصاصی',
    subtitle: 'Next-Gen Web & High-Speed Development',
    description: 'توسعه وب‌سایت‌های لوکس، فوق‌سریع و ریسپانسیو با رابط کاربری (UI/UX) مدرن، موشن‌های روان، معماری کد استاندارد و سئوی تکنیکال بهینه.',
    category: 'dev_automation',
    tags: ['React / Vite مدرن', 'انیمیشن‌های سه‌بعدی', 'سرعت لود زیر ۱ ثانیه', 'سئوی پایه'],
    startingPrice: 18000000,
    deliveryTime: '۷ تا ۱۴ روز کاری',
    popular: true,
    deliverables: ['سورس کد کامل و معماری ماژولار', 'طراحی ۱۰۰٪ ریسپانسیو در تمام دستگاه‌ها', 'داشبورد مدیریتی روان', '۱ سال پشتیبانی فنی']
  },
  {
    id: 'business-automation',
    number: '08',
    title: 'اتوماسیون و خودکار سازی کسب و کار ها',
    subtitle: 'Smart AI Workflow & System Integration',
    description: 'اتصال هوشمند سیستم‌ها، ربات‌های پاسخگوی اختصاصی تلگرام/واتساپ، یکپارچه‌سازی CRM و حذف فرآیندهای تکراری برای افزایش چشمگیر بهره‌وری.',
    category: 'dev_automation',
    tags: ['ربات‌های هوشمند تلگرام', 'اتصال CRM و پایگاه داده', 'فرآیندهای خودکار Zapier/Make', 'کاهش خطای انسانی'],
    startingPrice: 14000000,
    deliveryTime: '۵ تا ۱۰ روز کاری',
    deliverables: ['پایپ‌لاین کامل اتوماسیون بدون وقفه', 'مستندات راه‌اندازی و ویدیو آموزشی', 'پنل مانیتورینگ عملکرد ربات']
  },
  {
    id: 'digital-products-creation',
    number: '09',
    title: 'ساخت و انتشار محصولات دیجیتال',
    subtitle: 'Digital Assets, Templates & UI Kits',
    description: 'ایده‌پردازی تا اجرای کامل قالب‌های طراحی، پکیج‌های آموزشی تعاملی، ابزارهای آنلاین و دارایی‌های دیجیتال دارای پتانسیل فروش بی‌نهایت.',
    category: 'dev_automation',
    tags: ['کیت‌های رابط کاربری UI/UX', 'طراحی داشبورد و کامپوننت', 'محصولات درآمد غیرفعال', 'داکیومنت استاندارد'],
    startingPrice: 9500000,
    deliveryTime: '۵ تا ۸ روز کاری',
    deliverables: ['فایل Figma و کدهای ماژولار', 'سیستم طراحی (Design System)', 'صفحه لندینگ معرفی محصول']
  }
];
